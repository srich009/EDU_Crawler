export class Article {
  id: number;
  title: string;
  body: string;
}